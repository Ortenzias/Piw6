<?php
    header("Content-Type: text/css; charset: UTF-8");
?>

body {
    background-color: pink;
}

